### Hexlet tests and linter status:
[![Actions Status](https://github.com/deusmg/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/deusmg/python-project-49/actions)
[![Maintainability](https://api.codeclimate.com/v1/badges/6d870332c7f31108acd3/maintainability)](https://codeclimate.com/github/deusmg/python-project-49/maintainability)
